% file mcalc03.m    Data for opinion survey
minvec4
DV = [A|Ac; A; B; C; D; A&(B|Cc)&Dc; A|((B&C)|Dc) ; Ac&B&Cc&D; ...
      A&B&C&D; A&Bc&C; Ac&Bc&Cc&D; Ac&B&C; Ac&Bc&Dc; A&Cc; A&C&Dc; A&B&Cc&Dc];
DP =  0.001*[1000 200 500 300 700 55 520 200 15 30 195 120 120 ...
              140 25 20];
TV = [Ac&((B&Cc)|(Bc&C)); A|(B&Cc)];
disp('Call for mincalc')
