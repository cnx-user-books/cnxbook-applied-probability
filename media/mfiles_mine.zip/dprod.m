function y = dprod(X,Y)
% y =dprod(X,Y) dot product of vectors X,Y
% Version of 5/6/05
y = X*Y';