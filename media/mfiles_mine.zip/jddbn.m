%JDDBN file jddbn.m Joint discrete distribution function
% Version of 7/18/05
% Uses probability matrix arranged as on the plane
% to calculate the joint distribution function FXy.
% Uses cumsum and appropriate reorientations.
P = input('Enter joint probability matrix (as on the plane)  ');
f = flipud(cumsum(flipud(P)));
FXY = cumsum(f')';
disp('Call for FXY to view the distribution function')